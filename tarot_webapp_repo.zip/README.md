# Tarot WebApp for Telegram Bot

Это статический WebApp для выбора 3 карт Таро.

## Как использовать

1. Опубликуйте этот репозиторий на GitHub Pages или Vercel.
2. В `bot.py` замените URL WebAppInfo на:
   ```
   https://<ваш_пользователь>.github.io/tarot_webapp_repo/index.html
   ```
3. Перезапустите бота. WebApp откроется и будет передавать выбранные карты боту.
